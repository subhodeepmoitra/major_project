<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>new_hospital_registration</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="row register-form">
        <div class="col-md-8 offset-md-2">
            <form class="custom-form" action="registration_backend.php" method="POST">
                <h1>New Hospital Registration Form</h1>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Full Hospital Name</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="hname" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Regd. No.</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="registration" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Trade Licence No.</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="trade" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Owner's Name</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="ownername" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Email</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="email" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="name-input-field">Phone Number</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="phone" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="email-input-field">Address</label></div>
                    <div class="col-sm-6 input-column">
                        <input class="form-control" name="address" type="text" required></div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-4 label-column">
                        <label class="col-form-label" for="dropdown-input-field">City</label></div>
                    <div class="col-sm-4 input-column">
                        <div class="dropdown">
                            <button class="btn btn-light dropdown-toggle" aria-expanded="false" data-bs-toggle="dropdown" name="city" type="button"></button>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Kolkata</a>
                                <a class="dropdown-item" href="#">Bidhannagar</a>
                                <a class="dropdown-item" href="#">Howrah</a>
                                <a class="dropdown-item" href="#">Serampore</a>
                                <a class="dropdown-item" href="#">Bhadreshwar</a>
                                <a class="dropdown-item" href="#">Chandannagar</a>
                                <a class="dropdown-item" href="#">Chinsura</a>
                                <a class="dropdown-item" href="#">Bandel</a>
                                <a class="dropdown-item" href="#">Uttarpara</a>
                                <a class="dropdown-item" href="#">Salar</a>
                                <a class="dropdown-item" href="#">Salua</a>
                                <a class="dropdown-item" href="#">Purulia</a>
                                <a class="dropdown-item" href="#">Bashirhat</a>
                                <a class="dropdown-item" href="#">Hashnabad</a>
                                <a class="dropdown-item" href="#">Taki</a>
                                <a class="dropdown-item" href="#">Barrackpore</a>
                                <a class="dropdown-item" href="#">Katwa</a>
                                <a class="dropdown-item" href="#">Arambagh</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-check"><input class="form-check-input" type="checkbox" id="formCheck-1" require>
                <label class="form-check-label" for="formCheck-1">I've read and accept the terms and conditions</label>
            </div>
                <!--<button class="btn btn-light submit-button" type="button">Submit Form</button>-->
                <div class="btn btn-light submit-button">
                    <input type="submit" value="Submit and Exit">
                </div>
            </form>
        </div>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>