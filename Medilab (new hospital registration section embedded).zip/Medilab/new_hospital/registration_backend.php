<?php

$conn = mysqli_connect("localhost","root","","medilab");
$hname = isset($_POST['hname']) ? $_POST['hname'] : '';
$registration =isset($_POST['registration']) ? $_POST['registration'] : '';
$trade = isset($_POST['trade']) ? $_POST['trade'] : '';
$ownername = isset($_POST['ownername']) ? $_POST['ownername'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$phone = isset($_POST['phone']) ? $_POST['phone'] : '';
$address = isset($_POST['address']) ? $_POST['address'] : '';
$city = isset($_POST['city']) ? $_POST['city'] : '';

date_default_timezone_set('Asia/Kolkata');
$date = date("Y/m/d H:i:s");

$query = "INSERT INTO `hospital_registration`(`hname`, `registration`, `trade`, `ownername`, `email`, `phone`, `address`, `city`, `time`) VALUES ('$hname','$registration','$trade','$ownername','$email','$phone','$address','$city','$date')";
$execute = mysqli_query($conn, $query);
if($execute){
    echo"
         <h3>Registered Successfully</h3><br/>
         <p>Click <a href= '../index.php'> Here </a> </p>";
} else{
    echo "<h3>Requirements Failed</h3>";
}

?>