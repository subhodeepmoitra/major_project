<?php


include("auth.php"); //include auth.php file on all secure pages 
include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
<?php 
                               $user = $_SESSION['username'];
                               $sql = "SELECT username FROM `login` where username = '$user'";
                               $result = $con->query($sql);
                               
                               if (!empty($result) && $result->num_rows > 0) {
                                   // output data of each row
                                   while($row = $result->fetch_assoc()) {
                                       echo "Welcome";
                                       echo  $row["username"];
                                   }
                               } else {
                                   echo "0 results";
                               }
                             ?>
<p>This is secure area.</p>
<p><a href="dashboard.php">Dashboard</a></p>
<a href="logout.php">Logout</a>


<br /><br /><br /><br />

</div>
</body>
</html>
